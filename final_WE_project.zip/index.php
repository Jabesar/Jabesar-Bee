
<?php 
session_start();

	include("connection.php");
	include("functions.php");

	$user_data = check_login($con);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style_home.css">
</head>
<body>
     <div class="A">
        <div class="B">
            <h1>HOME</h1>
        </div>
        <div class="C">
            <a href="indian.html"><h4>INDIAN</h4>
            <a href="western_food.html" ><h4>ITALIAN</h4>
            <a href="western_food.html" > <h4>CHINESE</h4>
            <a href="western_food.html" > <h4>MEXICAN</h4>
            <a href="western_food.html" > <h4>KOREAN</h4>
            <a href="western_food.html" > <h4>FRENCH</h4>
            <a href="western_food.html" > <h4>TURKEY</h4>
            <a href="logout.php" > <h4>LOGOUT</h4>
        </div>
        <!-- <div class="E">
            <h5> for food lover</h5>
        </div>    -->
      </div>
    
    <div class="D">
        <hr class="D1">
        <div class="F">
            <h1>INSTANT FOOD ZONE</h1>
        </div>
        <hr class="D2">
        <div class="D3">
          <h4>Food may be essential as fuel for the body</h4>
          <h4> but Good food is fuel for the soul </h4>
        </div>
    </div>
   
    
  <div class="I">
    <br><br><br>
      <hr class="hr1" id="I4"><br><br>
       <h1>CONTACT US</h1>
      <br><br>
      <a href="mailto:porsiyaamrita@gmail.com"> <h6>JABESAR BEE</h6><br>
      <hr  id="I3"><br>
      <a href="mailto:porsiyaamrita@gmail.com"> <h6>AMRITA PORSIYA</h6><br>
      <hr  id="I3">
      <br>
      <a href="mailto:porsiyaamrita@gmail.com"><h6>ANSHI PARTETI</h6>
      <br>
      <hr  id="I3"><br><br>
      <h4>THANK YOU</h4><br>
      <br><br><br>
      <hr   id="I3">
      <br><br>
             
        
  </div> 
  
</body>
</html>